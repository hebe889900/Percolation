public class Percolation {

	private int[][] grid;
	private int[] id;
	private int count;
	private final int length;

	// creates n-by-n grid, with all sites initially blocked
	public Percolation(int n) {
		if (n <= 0) {
			throw new IllegalArgumentException();
		}
		this.grid = new int[n + 1][n + 1];
		this.id = new int[(n + 1) * (n + 1)];
		for (int i = 0; i < (n + 1) * (n + 1); i++)
			id[i] = i;		
		this.count = 0;
		this.length = n;
	}

	// opens the site (row, col) if it is not open already
	public void open(int row, int col) {
		if (row <= 0 || row > length || col <= 0 || col > length) {
			throw new IllegalArgumentException();
		}
		if (grid[row][col] == 0) {
			grid[row][col] = row * length + col;
			count++;
        	if(col > 1 && grid[row][col - 1] != 0) {
        		union(row * length + col, row * length + col - 1);
        	}
        	if(col < length && grid[row][col + 1] != 0) {
        		union(row * length + col, row * length + col + 1);
        	} 
        	if(row > 1 && grid[row - 1][col] != 0) {
        		union((row - 1) * length + col, row * length + col);
        	} 
        	if(row < length && grid[row + 1][col] != 0) {
        		union((row + 1) * length + col, row * length + col);
        	}        			
		}
	}

	private int find(int p) {
		return id[p];
	}

	private void union(int p, int q) {
		int pID = find(p);
		int qID = find(q);
		if (pID != 0 && qID != 0 && pID == qID)
			return;
		for (int i = 0; i < id.length; i++)
			if (id[i] == pID)
				id[i] = qID;
	}

	// is the site (row, col) open?
	public boolean isOpen(int row, int col) {
		if (row <= 0 || row > length || col <= 0 || col > length) {
			throw new IllegalArgumentException();
		}
		return grid[row][col] != 0;
	}

	private boolean connected(int p, int q) {
		return find(p) == find(q);
	}

	// is the site (row, col) full?
	public boolean isFull(int row, int col) {
		for (int i = 1; i <= length; i++) {
			boolean isOpen = isOpen(row, col);
			boolean isConnected = connected(row * length + col, length + i);
			if (isOpen && isConnected) {
				return true;
			}
		}
		return false;
	}


	// returns the number of open sites
	public int numberOfOpenSites() {
		return count;
	}

	// does the system percolate?
	public boolean percolates() {
		for (int i = 1; i <= length; i++) {
			boolean topIsOpen = isOpen(1, i);
			if (topIsOpen) {
				for (int j = 1; j <= length; j++) {
					boolean bottomIsOpen = isOpen(length, j);
					boolean isConnected = connected(length + i, length * length + j);
					if (bottomIsOpen && isConnected) {
						return true;
					}
				}
			}
		}
		return false;
	}

	// test client (optional)
	public static void main(String[] args) {
		int n = 2;
		Percolation Percolation = new Percolation(n);
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				Percolation.open(i, j);
			}
		}
		System.out.println(Percolation.percolates());
	}
}